/**
 * @file  Game_3.c
 * @brief Stub — this project has only two games (2-person group).
 *
 * game_3/Game_3.c exists only so that main.c and CMakeLists.txt from the
 * Unit 4.1 Menu Template compile without modification. The main menu only
 * displays two options, so Game3_Run() is never actually called.
 */
#include "Game_3.h"

MenuState Game3_Run(void)
{
    return MENU_STATE_HOME;
}
