/*
 * Game_1.c - Gravity Well
 *
 * My game for the ELEC2645 Unit 4 project. The idea came from wanting
 * to do something different with the joystick instead of moving the
 * craft directly, the joystick applies thrust and gravity does the rest.
 *
 * How I structured it:
 *   Game1_Run()       - my main loop, handles the state machine
 *   level_load()      - resets everything when starting a level
 *   physics_update()  - runs every frame, handles gravity + thrust
 *   check_dead()      - checks if I hit a well or flew off screen
 *   check_goal()      - checks if I reached the goal ring
 *   render_game()     - draws everything to the LCD each frame
 *   proximity_buzz()  - makes the buzzer pitch change near wells
 *
 * Physics:
 *   I'm using float throughout because the STM32L476 has a hardware FPU
 *   so it costs almost nothing extra. Each frame I compute gravity from
 *   every well using the inverse-square law:
 *
 *     r  = distance from craft to well
 *     a  = G_CONST * mass / (r * r)
 *     a  = min(a, ACCEL_CAP)        <- I cap this to stop instant death near centre
 *     ax += a * (well.x - craft.x) / r
 *     ay += a * (well.y - craft.y) / r
 *
 *   If the joystick is pushed I add thrust on top:
 *     ax += jx * THRUST
 *     ay -= jy * THRUST    <- minus because LCD y grows downward
 *     fuel -= FUEL_RATE
 *
 *   Then I integrate with Euler which works fine at 30 FPS:
 *     vx += ax;  vy += ay
 *     clamp speed to V_MAX
 *     px += vx;  py += vy
 *
 * Level data:
 *   I store each level as a const array in Flash to save RAM.
 *   level_load() copies it into a mutable Well_t array so oscillating
 *   wells can update their position each frame.
 *
 * Buzzer / LED:
 *   The buzzer pitch rises the closer I get to a well I thought this
 *   felt more natural than a flat beep. The LED dims as fuel runs out
 *   so there is a visual warning even when not looking at the fuel bar.
 */

#include "Game_1.h"
#include "InputHandler.h"
#include "Menu.h"
#include "LCD.h"
#include "PWM.h"
#include "Buzzer.h"
#include "Joystick.h"
#include "stm32l4xx_hal.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

/* globals I need from main.c */
extern ST7789V2_cfg_t cfg0;
extern PWM_cfg_t      pwm_cfg;
extern Buzzer_cfg_t   buzzer_cfg;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t     joystick_data;

/* screen and timing */
#define FRAME_MS    33       /* targeting 30 FPS so 33ms per frame         */
#define SCREEN_W   240
#define SCREEN_H   240
#define HUD_H       20       /* 20px reserved at the top for level and fuel */
#define PLAY_H     (SCREEN_H - HUD_H)

/* physics values - tuned by feel until it played well */
#define G_CONST       900.0f  /* how strongly wells pull                    */
#define ACCEL_CAP       2.2f  /* max pull per well stops instant death near centre */
#define THRUST          0.18f /* how much the joystick accelerates the craft */
#define BOOST_MULT      2.0f  /* BTN2 doubles thrust, doubles fuel cost     */
#define V_MAX           4.5f  /* cap speed so the craft stays controllable  */
#define FUEL_RATE       0.004f
#define FUEL_RATE_BOOST 0.010f

#define GOAL_RADIUS    14.0f  /* how close I need to get to the goal ring   */

/* proximity alarm - pitch rises as I get closer to a well */
#define ALARM_DIST     60.0f
#define ALARM_BASE_HZ  300
#define ALARM_SCALE    8000.0f
#define ALARM_VOL       35

#define TRAIL_LEN   12  /* store the last 12 positions to draw a motion trail */

/* ----- data types ---------------------------------------------------- */

/*
 * I split the well data into two structs:
 * WellDesc_t is const and lives in Flash (the level definitions)
 * Well_t is a mutable runtime copy so oscillating wells can move each frame
 */
typedef struct {
    float base_x, base_y;
    float mass;
    float kill_r;     /* entering this radius = instant death              */
    float vis_r;      /* outer drawn ring, shows roughly where gravity is  */
    uint8_t oscillates;
    float osc_amp;    /* half amplitude of left-right oscillation in px    */
} WellDesc_t;

typedef struct {
    float x, y;
    float mass, kill_r, vis_r;
    float osc_base_x, osc_amp;
    uint8_t oscillates;
} Well_t;

/* everything about the craft in one place */
typedef struct {
    float px, py;            /* position                                   */
    float vx, vy;            /* velocity                                   */
    float fuel;              /* 0.0 = empty, 1.0 = full                   */
    float trail_x[TRAIL_LEN];
    float trail_y[TRAIL_LEN];
    uint8_t trail_head;      /* ring buffer head                           */
} Craft_t;

/* ----- level data ----------------------------------------------------- */

/* two mass values I use across the levels */
#define M_STD  0.28f   /* manageable pull                                  */
#define M_HVY  0.42f   /* noticeably stronger                              */

/* Level 1 - two wells above and below, gentle warm up */
static const WellDesc_t L1_wells[] = {
    { 120,  76, M_STD, 18, 24, 0, 0 },
    { 120, 172, M_STD, 18, 24, 0, 0 },
};

/* Level 2 - three wells in a triangle, need to pick a route */
static const WellDesc_t L2_wells[] = {
    {  78,  68, M_STD, 18, 24, 0, 0 },
    { 168, 104, M_HVY, 20, 27, 0, 0 },
    {  90, 180, M_STD, 18, 24, 0, 0 },
};

/*
 * Level 3 - four wells making a horizontal corridor.
 * I moved the spawn to (20, 118) after testing showed the original
 * position was too close to a well and the craft got pulled in before
 * I could do anything. I also reduced oscillation from 36 to 20px.
 */
static const WellDesc_t L3_wells[] = {
    {  80,  65, M_STD, 16, 22, 0,  0 }, /* top left                      */
    { 160,  65, M_STD, 16, 22, 0,  0 }, /* top right                     */
    { 120, 128, M_STD, 15, 20, 1, 20 }, /* middle, oscillates left/right  */
    { 120, 188, M_STD, 16, 22, 0,  0 }, /* bottom                        */
};

/* Level 4 - 2x2 grid of heavy wells, fly down the centre gap */
static const WellDesc_t L4_wells[] = {
    {  72,  82, M_HVY, 22, 28, 0, 0 },
    { 168,  82, M_HVY, 22, 28, 0, 0 },
    {  72, 174, M_HVY, 22, 28, 0, 0 },
    { 168, 174, M_HVY, 22, 28, 0, 0 },
};

/* Level 5 - hardest: five wells, one oscillates a lot, fuel is tight */
static const WellDesc_t L5_wells[] = {
    {  74,  64, M_HVY, 22, 28, 0,  0 },
    { 166,  64, M_HVY, 22, 28, 0,  0 },
    { 120, 128, M_HVY, 20, 26, 1, 44 }, /* this one swings +-44px       */
    {  74, 192, M_HVY, 22, 28, 0,  0 },
    { 166, 192, M_HVY, 22, 28, 0,  0 },
};

typedef struct {
    const WellDesc_t* wells;
    uint8_t           well_count;
    float             start_x, start_y;
    float             goal_x,  goal_y;
    float             fuel_start;
} LevelDesc_t;

#define NUM_LEVELS 5
static const LevelDesc_t levels[NUM_LEVELS] = {
    { L1_wells, 2,  30, 128, 210, 128, 1.00f },
    { L2_wells, 3,  30, 195, 212,  52, 0.90f },
    { L3_wells, 4,  20, 118, 220, 118, 0.90f }, /* spawn left-centre, goal right-centre */
    { L4_wells, 4, 120,  28, 120, 218, 0.70f },
    { L5_wells, 5,  22, 128, 220, 128, 0.55f },
};

/* ----- module-level state -------------------------------------------- */
#define MAX_WELLS 6
static Well_t      wells[MAX_WELLS];
static uint8_t     well_count;
static Craft_t     craft;
static LevelDesc_t cur_level;
static float       osc_t;            /* phase counter for oscillating wells */
static uint32_t    buzzer_stop_tick; /* non-blocking buzzer timer           */

/* my internal states */
typedef enum {
    G1_TITLE = 0,
    G1_PLAY,
    G1_DEAD,
    G1_CLEAR,
    G1_WIN,
} G1State_t;

/* ----- forward declarations ------------------------------------------ */
static void    level_load(uint8_t idx);
static void    physics_update(void);
static uint8_t check_dead(void);
static uint8_t check_goal(void);
static void    render_game(uint8_t level_idx);
static void    render_overlay(const char* l1, const char* l2, const char* l3);
static void    proximity_buzz(void);
static void    sfx_once(uint32_t hz, uint16_t ms);
static void    sfx_tick(void);
static void    draw_well(const Well_t* w);
static void    draw_craft(void);
static void    draw_goal(float gx, float gy, uint8_t flash);
static void    draw_fuel_bar(float fuel);

/* ===================================================================
 * Game1_Run
 * Called by main.c when Gravity Well is selected from the menu.
 * Runs its own loop until BTN3 is pressed, then returns HOME.
 * =================================================================== */
MenuState Game1_Run(void)
{
    G1State_t state      = G1_TITLE;
    uint32_t  state_tick = HAL_GetTick();
    uint8_t   level_idx  = 0;

    PWM_SetDuty(&pwm_cfg, 80); /* LED on when entering the game           */

    while (1)
    {
        uint32_t t0 = HAL_GetTick();

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);

        /* BTN3 always returns to the main menu from any state */
        if (current_input.btn3_pressed) {
            buzzer_off(&buzzer_cfg);
            PWM_SetDuty(&pwm_cfg, 50);
            return MENU_STATE_HOME;
        }

        switch (state)
        {
        /* title / instructions screen */
        case G1_TITLE:
            LCD_Fill_Buffer(0);
            LCD_printString("GRAVITY WELL",    30, 28, 1, 2);
            LCD_Draw_Line(0, 55, 239, 55, 15);
            LCD_printString("Joystick = Thrust",  20,  72, 1, 1);
            LCD_printString("BTN2     = Boost",   20,  90, 1, 1);
            LCD_printString("BTN3     = Menu",    20, 108, 1, 1);
            LCD_printString("Reach the goal ring", 10, 132, 1, 1);
            LCD_printString("without being pulled", 8, 148, 1, 1);
            LCD_printString("into a gravity well.", 8, 164, 1, 1);
            if (((HAL_GetTick() - state_tick) / 400) % 2 == 0)
                LCD_printString("BTN2 = Start", 64, 200, 1, 1);
            LCD_Refresh(&cfg0);
            if (current_input.btn2_pressed) {
                level_idx = 0;
                level_load(level_idx);
                state      = G1_PLAY;
                state_tick = HAL_GetTick();
                sfx_once(880, 50);
            }
            break;

        /* main gameplay */
        case G1_PLAY:
            physics_update();
            sfx_tick();
            if (check_dead()) {
                state      = G1_DEAD;
                state_tick = HAL_GetTick();
                sfx_once(200, 200);
                PWM_SetDuty(&pwm_cfg, 0);
            } else if (check_goal()) {
                buzzer_off(&buzzer_cfg);
                state      = G1_CLEAR;
                state_tick = HAL_GetTick();
                sfx_once(1400, 80);
                PWM_SetDuty(&pwm_cfg, 90);
            } else {
                proximity_buzz();
            }
            render_game(level_idx);
            break;

        /* craft got pulled into a well or flew off screen */
        case G1_DEAD:
            sfx_tick();
            render_overlay("PULLED IN!", "Fuel lost to the void.",
                           "BTN2: Retry  BTN3: Menu");
            if (current_input.btn2_pressed) {
                level_load(level_idx);
                state      = G1_PLAY;
                state_tick = HAL_GetTick();
            }
            break;

        /* reached the goal - load next level or show win screen */
        case G1_CLEAR:
        {
            char msg[24];
            snprintf(msg, sizeof(msg), "Level %u Clear!", level_idx + 1);
            render_overlay(msg, "BTN2: Next level", "BTN3: Menu");
            if (current_input.btn2_pressed) {
                level_idx++;
                if (level_idx >= NUM_LEVELS) {
                    state      = G1_WIN;
                    state_tick = HAL_GetTick();
                    sfx_once(1760, 120);
                } else {
                    level_load(level_idx);
                    state      = G1_PLAY;
                    state_tick = HAL_GetTick();
                    sfx_once(1100, 60);
                }
            }
            break;
        }

        /* all five levels done */
        case G1_WIN:
            sfx_tick();
            render_overlay("ALL 5 LEVELS DONE!",
                           "Excellent piloting.",
                           "BTN2: Play again  BTN3: Menu");
            if (current_input.btn2_pressed) {
                level_idx = 0;
                level_load(0);
                state      = G1_PLAY;
                state_tick = HAL_GetTick();
            }
            break;
        }

        /* cap to 30 FPS */
        uint32_t elapsed = HAL_GetTick() - t0;
        if (elapsed < FRAME_MS) HAL_Delay(FRAME_MS - elapsed);
    }
}

/* -------------------------------------------------------------------
 * level_load - sets up the craft and wells for a given level
 * ------------------------------------------------------------------- */
static void level_load(uint8_t idx)
{
    cur_level  = levels[idx];
    well_count = cur_level.well_count;
    osc_t      = 0.0f;

    /* copy the const Flash descriptors into my mutable runtime array */
    for (uint8_t i = 0; i < well_count; i++) {
        const WellDesc_t* d = &cur_level.wells[i];
        wells[i].x          = d->base_x;
        wells[i].y          = d->base_y;
        wells[i].mass       = d->mass;
        wells[i].kill_r     = d->kill_r;
        wells[i].vis_r      = d->vis_r;
        wells[i].oscillates = d->oscillates;
        wells[i].osc_base_x = d->base_x;
        wells[i].osc_amp    = d->osc_amp;
    }

    /* placing the craft at the start with zero velocity */
    craft.px         = cur_level.start_x;
    craft.py         = cur_level.start_y + HUD_H; /* adding HUD height offset */
    craft.vx         = 0.0f;
    craft.vy         = 0.0f;
    craft.fuel       = cur_level.fuel_start;
    craft.trail_head = 0;

    /* filling trail with start position so there is no garbage on screen */
    for (uint8_t i = 0; i < TRAIL_LEN; i++) {
        craft.trail_x[i] = craft.px;
        craft.trail_y[i] = craft.py;
    }

    buzzer_stop_tick = 0;
    PWM_SetDuty(&pwm_cfg, (uint8_t)(craft.fuel * 80.0f));
}

/* -------------------------------------------------------------------
 * physics_update - the core simulation, called every frame in G1_PLAY
 * ------------------------------------------------------------------- */
static void physics_update(void)
{
    /* push current position into the trail ring buffer */
    craft.trail_head = (craft.trail_head + 1) % TRAIL_LEN;
    craft.trail_x[craft.trail_head] = craft.px;
    craft.trail_y[craft.trail_head] = craft.py;

    /*
     * Advance the oscillation phase. I add 0.026 radians per frame
     * which works out to roughly an 8 second full cycle.
     */
    osc_t += 0.026f;
    for (uint8_t i = 0; i < well_count; i++) {
        if (wells[i].oscillates)
            wells[i].x = wells[i].osc_base_x + wells[i].osc_amp * sinf(osc_t);
    }

    /* accumulate gravitational pull from every well */
    float ax = 0.0f, ay = 0.0f;
    for (uint8_t i = 0; i < well_count; i++) {
        float dx   = wells[i].x - craft.px;
        float dy   = (wells[i].y + HUD_H) - craft.py;
        float dist = sqrtf(dx * dx + dy * dy);
        if (dist < 1.0f) dist = 1.0f; /* avoid dividing by zero           */
        float a = G_CONST * wells[i].mass / (dist * dist);
        if (a > ACCEL_CAP) a = ACCEL_CAP; /* cap so craft doesn't teleport */
        ax += a * dx / dist;
        ay += a * dy / dist;
    }

    /* add thrust if the joystick is pushed and I have fuel */
    float jx          = joystick_data.coord_mapped.x; /* +1 = right       */
    float jy          = joystick_data.coord_mapped.y; /* +1 = up          */
    float thrust_mult = THRUST;
    uint8_t thrusting = (joystick_data.direction != CENTRE);

    if (thrusting) {
        if (current_input.btn2_pressed) thrust_mult = THRUST * BOOST_MULT;
        if (craft.fuel > 0.0f) {
            ax += jx * thrust_mult;
            ay -= jy * thrust_mult; /* LCD y is flipped relative to game y  */
            float cost = (thrust_mult > THRUST) ? FUEL_RATE_BOOST : FUEL_RATE;
            craft.fuel -= cost;
            if (craft.fuel < 0.0f) craft.fuel = 0.0f;
        }
    }

    /* Euler integration */
    craft.vx += ax;
    craft.vy += ay;

    /* clamp to max speed */
    float speed = sqrtf(craft.vx * craft.vx + craft.vy * craft.vy);
    if (speed > V_MAX) {
        craft.vx *= V_MAX / speed;
        craft.vy *= V_MAX / speed;
    }

    /* move the craft */
    craft.px += craft.vx;
    craft.py += craft.vy;

    /* keep LED brightness matching fuel level */
    PWM_SetDuty(&pwm_cfg, (uint8_t)(craft.fuel * 80.0f + 5.0f));
}

/* -------------------------------------------------------------------
 * check_dead - returns 1 if the craft should die this frame
 * ------------------------------------------------------------------- */
static uint8_t check_dead(void)
{
    /* flew off screen */
    if (craft.px < 0 || craft.px >= SCREEN_W ||
        craft.py < HUD_H || craft.py >= SCREEN_H)
        return 1;

    /* entered a well's kill radius */
    for (uint8_t i = 0; i < well_count; i++) {
        float dx = wells[i].x - craft.px;
        float dy = (wells[i].y + HUD_H) - craft.py;
        if (sqrtf(dx * dx + dy * dy) < wells[i].kill_r) return 1;
    }
    return 0;
}

/* -------------------------------------------------------------------
 * check_goal - returns 1 when I'm close enough to the goal ring
 * ------------------------------------------------------------------- */
static uint8_t check_goal(void)
{
    float dx = cur_level.goal_x - craft.px;
    float dy = (cur_level.goal_y + HUD_H) - craft.py;
    return (sqrtf(dx * dx + dy * dy) < GOAL_RADIUS) ? 1 : 0;
}

/* -------------------------------------------------------------------
 * render_game - full redraw every frame
 * ------------------------------------------------------------------- */
static void render_game(uint8_t level_idx)
{
    LCD_Fill_Buffer(0);

    /* HUD */
    char hud[32];
    snprintf(hud, sizeof(hud), "Level %u/5", level_idx + 1);
    LCD_printString(hud, 4, 4, 1, 1);
    LCD_printString("Fuel:", 140, 4, 1, 1);
    draw_fuel_bar(craft.fuel);
    LCD_Draw_Line(0, HUD_H - 1, SCREEN_W - 1, HUD_H - 1, 15);

    /* goal ring - I flash it at roughly 2 Hz so it is easy to spot */
    uint8_t flash = ((HAL_GetTick() / 250) % 2 == 0);
    draw_goal(cur_level.goal_x, cur_level.goal_y + HUD_H, flash);

    /* small X to mark the start position */
    float sx = cur_level.start_x, sy = cur_level.start_y + HUD_H;
    LCD_Draw_Line((uint16_t)(sx-5),(uint16_t)(sy-5),(uint16_t)(sx+5),(uint16_t)(sy+5),15);
    LCD_Draw_Line((uint16_t)(sx+5),(uint16_t)(sy-5),(uint16_t)(sx-5),(uint16_t)(sy+5),15);

    /* all wells */
    for (uint8_t i = 0; i < well_count; i++)
        draw_well(&wells[i]);

    /* trail - skip some older dots to keep rendering fast */
    for (uint8_t t = 1; t < TRAIL_LEN; t++) {
        uint8_t idx = (craft.trail_head + TRAIL_LEN - t) % TRAIL_LEN;
        if (t <= 4 || (t % 3 == 0))
            LCD_Set_Pixel((uint16_t)craft.trail_x[idx],
                          (uint16_t)craft.trail_y[idx], 15);
    }

    draw_craft();
    LCD_Refresh(&cfg0);
}

/* -------------------------------------------------------------------
 * render_overlay - three-line message screen used for DEAD/CLEAR/WIN
 * ------------------------------------------------------------------- */
static void render_overlay(const char* l1, const char* l2, const char* l3)
{
    LCD_Fill_Buffer(0);
    LCD_printString(l1, 10,  70, 1, 2);
    LCD_printString(l2, 10, 110, 1, 1);
    LCD_printString(l3, 10, 135, 1, 1);
    LCD_Refresh(&cfg0);
}

/* -------------------------------------------------------------------
 * proximity_buzz
 * I find the nearest well each frame and map its distance to a pitch.
 * The tone is non blocking - I set a stop tick and sfx_tick() silences
 * it later so it never stalls the main loop.
 * ------------------------------------------------------------------- */
static void proximity_buzz(void)
{
    float nearest = 9999.0f;
    for (uint8_t i = 0; i < well_count; i++) {
        float dx   = wells[i].x - craft.px;
        float dy   = (wells[i].y + HUD_H) - craft.py;
        float dist = sqrtf(dx * dx + dy * dy);
        if (dist < nearest) nearest = dist;
    }

    if (nearest < ALARM_DIST) {
        uint32_t freq = (uint32_t)(ALARM_BASE_HZ + ALARM_SCALE / nearest);
        if (freq > 3000) freq = 3000;
        buzzer_tone(&buzzer_cfg, freq, ALARM_VOL);
        buzzer_stop_tick = HAL_GetTick() + 30;
    } else {
        sfx_tick(); /* silence once I have moved away                      */
    }
}

/* -------------------------------------------------------------------
 * sfx helpers - I use these so sound effects never block the frame loop
 * ------------------------------------------------------------------- */
static void sfx_once(uint32_t hz, uint16_t ms)
{
    buzzer_tone(&buzzer_cfg, hz, 40);
    buzzer_stop_tick = HAL_GetTick() + ms;
}

static void sfx_tick(void)
{
    if (buzzer_stop_tick != 0 &&
        (int32_t)(HAL_GetTick() - buzzer_stop_tick) >= 0)
    {
        buzzer_off(&buzzer_cfg);
        buzzer_stop_tick = 0;
    }
}

/* -------------------------------------------------------------------
 * drawing helpers
 * ------------------------------------------------------------------- */

static void draw_well(const Well_t* w)
{
    uint16_t cx = (uint16_t)w->x;
    uint16_t cy = (uint16_t)(w->y + HUD_H);

    /* filled white disc for the dangerous inner zone */
    LCD_Draw_Circle(cx, cy, (uint16_t)w->kill_r, 15, 1);

    /* black centre makes it look like a hole rather than a blob */
    if (w->kill_r > 5)
        LCD_Draw_Circle(cx, cy, (uint16_t)(w->kill_r - 4), 0, 1);

    /* outer ring gives a rough idea of how far the gravity reaches */
    LCD_Draw_Circle(cx, cy, (uint16_t)w->vis_r, 15, 0);
}

static void draw_craft(void)
{
    uint16_t cx = (uint16_t)craft.px;
    uint16_t cy = (uint16_t)craft.py;

    /* small filled circle for the craft body */
    LCD_Draw_Circle(cx, cy, 4, 15, 1);

    /* short line showing my current direction of travel */
    float speed = sqrtf(craft.vx * craft.vx + craft.vy * craft.vy);
    if (speed > 0.5f) {
        uint16_t tx = (uint16_t)(craft.px + craft.vx * 7.0f / speed * 3.0f);
        uint16_t ty = (uint16_t)(craft.py + craft.vy * 7.0f / speed * 3.0f);
        LCD_Draw_Line(cx, cy, tx, ty, 15);
    }
}

static void draw_goal(float gx, float gy, uint8_t flash)
{
    uint16_t cx = (uint16_t)gx;
    uint16_t cy = (uint16_t)gy;
    if (flash) {
        LCD_Draw_Circle(cx, cy, (uint16_t)GOAL_RADIUS, 15, 0);
        LCD_Draw_Line(cx - 8, cy, cx + 8, cy, 15); /* crosshair           */
        LCD_Draw_Line(cx, cy - 8, cx, cy + 8, 15);
    } else {
        LCD_Draw_Circle(cx, cy, (uint16_t)(GOAL_RADIUS - 3), 15, 0);
    }
}

static void draw_fuel_bar(float fuel)
{
    uint16_t bar_w = (uint16_t)(fuel * 54.0f);
    LCD_Draw_Rect(180, 4, 54, 8, 15, 0); /* outline                       */
    if (bar_w > 0)
        LCD_Draw_Rect(181, 5, bar_w, 6, 15, 1); /* fill                   */
}
