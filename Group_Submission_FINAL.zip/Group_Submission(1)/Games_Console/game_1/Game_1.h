/**
 * @file  Game_1.h
 * @brief Gravity Well — a physics-based spacecraft navigation game.
 *
 * The player's craft has inertia: the joystick applies THRUST, not direct
 * movement. Gravity wells scattered around each level continuously attract
 * the craft. The goal is to navigate from the start marker to the goal
 * marker without being captured by a well, flying off-screen, or exhausting
 * the limited fuel supply.
 *
 * Five hand-designed levels of increasing complexity; level 3 introduces
 * an oscillating well that makes the safe corridor unpredictable.
 *
 * Hardware used:
 *   Joystick  — apply thrust (all 8 directions)
 *   BTN2      — boost (double thrust, double fuel cost) for emergencies
 *   BTN3      — quit back to the main menu (from any sub-state)
 *   Buzzer    — proximity alarm: pitch rises as you approach a well
 *   PWM LED   — fuel gauge: dims as fuel is consumed
 */
#ifndef GAME_1_H
#define GAME_1_H

#include "Menu.h"

/**
 * @brief Run Gravity Well until the player wins all levels or quits.
 * @return MENU_STATE_HOME when the player exits.
 */
MenuState Game1_Run(void);

#endif /* GAME_1_H */
