#include "Game_2.h"
#include "InputHandler.h"
#include "Menu.h"
#include "LCD.h"
#include "PWM.h"
#include "Buzzer.h"
#include "Joystick.h"
#include "stm32l4xx_hal.h"
#include <stdio.h>

extern ST7789V2_cfg_t cfg0;
extern PWM_cfg_t pwm_cfg;
extern Buzzer_cfg_t buzzer_cfg;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t joystick_data;

#define BLACK 0
#define WHITE 1
#define RED 2
#define GREEN 3
#define BLUE 4
#define ORANGE 5
#define YELLOW 6
#define GOLD 10
#define BROWN 12
#define GREY 13
#define CYAN 14

#define LANE_LEFT 75
#define LANE_MID 120
#define LANE_RIGHT 165

#define PLAYER_Y 182
#define FRAME_MS 45
#define MOVE_DELAY 160

static int player_lane;
static int spike_lane;
static int spike_y;
static int coin_lane;
static int coin_y;
static int score;
static int lives;
static int speed;
static int game_over;

static uint32_t seed;
static uint32_t last_move;
static uint32_t start_time;

static int lane_x(int lane)
{
    if (lane == 0) return LANE_LEFT;
    if (lane == 1) return LANE_MID;
    return LANE_RIGHT;
}

static int random_int(int max)
{
    seed = seed * 1103515245 + 12345;
    return (seed / 65536) % max;
}

static void reset_spike(void)
{
    spike_lane = random_int(3);
    spike_y = 30;
}

static void reset_coin(void)
{
    coin_lane = random_int(3);
    coin_y = 20;
}

static void reset_game(void)
{
    player_lane = 1;
    score = 0;
    lives = 3;
    speed = 4;
    game_over = 0;
    seed = HAL_GetTick();
    last_move = 0;
    start_time = HAL_GetTick();

    reset_spike();
    reset_coin();

    PWM_SetDuty(&pwm_cfg, 0);
}

static void beep_start(void)
{
    buzzer_tone(&buzzer_cfg, 900, 35);
    HAL_Delay(40);
    buzzer_tone(&buzzer_cfg, 1300, 35);
    HAL_Delay(40);
    buzzer_tone(&buzzer_cfg, 1600, 45);
    HAL_Delay(50);
    buzzer_off(&buzzer_cfg);
}

static void beep_coin(void)
{
    buzzer_tone(&buzzer_cfg, 1500, 25);
    HAL_Delay(25);
    buzzer_off(&buzzer_cfg);
}

static void beep_hit(void)
{
    buzzer_tone(&buzzer_cfg, 250, 90);
    HAL_Delay(100);
    buzzer_off(&buzzer_cfg);
}

static void blink_led_hit(void)
{
    for (int i = 0; i < 3; i++)
    {
        PWM_SetDuty(&pwm_cfg, 100);
        HAL_Delay(80);
        PWM_SetDuty(&pwm_cfg, 0);
        HAL_Delay(80);
    }
}

static void draw_title_screen(void)
{
    LCD_Fill_Buffer(BLACK);

    LCD_Draw_Rect(22, 45, 25, 125, BROWN, 1);
    LCD_Draw_Rect(193, 45, 25, 125, BROWN, 1);

    LCD_Draw_Rect(16, 40, 37, 10, GOLD, 1);
    LCD_Draw_Rect(187, 40, 37, 10, GOLD, 1);
    LCD_Draw_Rect(16, 165, 37, 8, GOLD, 1);
    LCD_Draw_Rect(187, 165, 37, 8, GOLD, 1);

    LCD_Draw_Line(40, 35, 120, 10, GOLD);
    LCD_Draw_Line(120, 10, 200, 35, GOLD);
    LCD_Draw_Rect(55, 35, 130, 5, GOLD, 1);

    LCD_printString("TEMPLE", 62, 58, GOLD, 3);
    LCD_printString("RUN", 88, 92, GOLD, 3);

    LCD_printString("SPIKE ESCAPE", 58, 130, ORANGE, 1);

    LCD_Draw_Circle(120, 153, 7, GOLD, 1);
    LCD_Draw_Rect(114, 161, 12, 16, ORANGE, 1);
    LCD_Draw_Line(114, 166, 104, 174, GOLD);
    LCD_Draw_Line(126, 166, 136, 174, GOLD);
    LCD_Draw_Line(118, 177, 110, 190, BROWN);
    LCD_Draw_Line(122, 177, 130, 190, BROWN);
    LCD_Draw_Rect(109, 143, 22, 4, BROWN, 1);
    LCD_Draw_Rect(114, 137, 12, 7, BROWN, 1);

    LCD_Draw_Line(55, 202, 185, 202, WHITE);
    LCD_printString("PRESS BUTTON", 64, 208, WHITE, 1);

    LCD_printString("START", 18, 229, GREEN, 1);
    LCD_printString("MENU", 178, 229, RED, 1);

    LCD_Refresh(&cfg0);
}

static void draw_background(void)
{
    LCD_Fill_Buffer(BROWN);

    LCD_Draw_Rect(0, 0, 45, 240, BROWN, 1);
    LCD_Draw_Rect(195, 0, 45, 240, BROWN, 1);

    LCD_Draw_Rect(7, 10, 8, 220, GREEN, 1);
    LCD_Draw_Rect(28, 10, 8, 220, GREEN, 1);
    LCD_Draw_Rect(205, 10, 8, 220, GREEN, 1);
    LCD_Draw_Rect(225, 10, 8, 220, GREEN, 1);

    for (int y = 30; y < 220; y += 35)
    {
        LCD_Draw_Line(7, y, 15, y, YELLOW);
        LCD_Draw_Line(28, y, 36, y, YELLOW);
        LCD_Draw_Line(205, y, 213, y, YELLOW);
        LCD_Draw_Line(225, y, 233, y, YELLOW);
    }

    LCD_Draw_Line(7, 45, 36, 45, GREEN);
    LCD_Draw_Line(7, 95, 36, 95, GREEN);
    LCD_Draw_Line(7, 145, 36, 145, GREEN);
    LCD_Draw_Line(7, 195, 36, 195, GREEN);

    LCD_Draw_Line(205, 45, 233, 45, GREEN);
    LCD_Draw_Line(205, 95, 233, 95, GREEN);
    LCD_Draw_Line(205, 145, 233, 145, GREEN);
    LCD_Draw_Line(205, 195, 233, 195, GREEN);

    LCD_Draw_Rect(45, 0, 150, 240, BLACK, 1);
}

static void draw_road(void)
{
    int y;

    LCD_Draw_Line(45, 0, 45, 240, GOLD);
    LCD_Draw_Line(195, 0, 195, 240, GOLD);

    for (y = 8; y < 220; y += 30)
    {
        LCD_Draw_Rect(96, y, 7, 14, BROWN, 1);
        LCD_Draw_Rect(137, y, 7, 14, BROWN, 1);
    }

    LCD_Draw_Rect(55, 214, 130, 5, GOLD, 1);
    LCD_Draw_Rect(60, 220, 120, 3, BROWN, 1);
}

static void draw_player(void)
{
    int x = lane_x(player_lane);

    LCD_Draw_Rect(x - 12, PLAYER_Y + 38, 24, 3, GREY, 1);

    LCD_Draw_Line(x - 4, PLAYER_Y + 24, x - 11, PLAYER_Y + 36, BROWN);
    LCD_Draw_Line(x + 4, PLAYER_Y + 24, x + 11, PLAYER_Y + 36, BROWN);

    LCD_Draw_Rect(x - 7, PLAYER_Y + 8, 14, 17, ORANGE, 1);

    LCD_Draw_Line(x - 7, PLAYER_Y + 14, x - 15, PLAYER_Y + 20, GOLD);
    LCD_Draw_Line(x + 7, PLAYER_Y + 14, x + 15, PLAYER_Y + 20, GOLD);

    LCD_Draw_Circle(x, PLAYER_Y, 7, GOLD, 1);

    LCD_Draw_Rect(x - 11, PLAYER_Y - 10, 22, 4, BROWN, 1);
    LCD_Draw_Rect(x - 6, PLAYER_Y - 16, 12, 7, BROWN, 1);
}

static void draw_coin(void)
{
    int x = lane_x(coin_lane);

    LCD_Draw_Circle(x, coin_y, 7, GOLD, 1);
    LCD_Draw_Circle(x, coin_y, 3, YELLOW, 0);
}

static void draw_spike(void)
{
    int x = lane_x(spike_lane);

    LCD_Draw_Rect(x - 16, spike_y + 8, 32, 6, GREY, 1);

    LCD_Draw_Line(x - 14, spike_y + 8, x - 8, spike_y - 8, WHITE);
    LCD_Draw_Line(x - 8, spike_y - 8, x - 2, spike_y + 8, WHITE);

    LCD_Draw_Line(x - 5, spike_y + 8, x, spike_y - 10, WHITE);
    LCD_Draw_Line(x, spike_y - 10, x + 5, spike_y + 8, WHITE);

    LCD_Draw_Line(x + 2, spike_y + 8, x + 8, spike_y - 8, WHITE);
    LCD_Draw_Line(x + 8, spike_y - 8, x + 14, spike_y + 8, WHITE);

    LCD_Draw_Line(x - 16, spike_y + 15, x + 16, spike_y + 15, RED);
}

static void draw_hud(void)
{
    char txt[20];

    LCD_Draw_Rect(72, 4, 95, 18, BROWN, 1);
    sprintf(txt, "SCORE %d", score);
    LCD_printString(txt, 82, 8, WHITE, 1);

    LCD_printString("LIFE", 6, 225, WHITE, 1);

    for (int i = 0; i < lives; i++)
    {
        LCD_Draw_Circle(45 + (i * 12), 230, 4, RED, 1);
    }
}

static void draw_play_screen(void)
{
    draw_background();
    draw_road();
    draw_hud();
    draw_coin();
    draw_spike();
    draw_player();

    LCD_Refresh(&cfg0);
}

static void draw_game_over(void)
{
    char txt[30];
    uint32_t time_s = (HAL_GetTick() - start_time) / 1000;

    LCD_Fill_Buffer(BROWN);

    LCD_Draw_Rect(22, 18, 196, 190, BLACK, 1);
    LCD_Draw_Line(30, 30, 210, 30, GOLD);
    LCD_Draw_Line(30, 198, 210, 198, GOLD);
    LCD_Draw_Line(30, 30, 30, 198, GOLD);
    LCD_Draw_Line(210, 30, 210, 198, GOLD);

    LCD_Draw_Line(45, 42, 65, 60, GREY);
    LCD_Draw_Line(190, 45, 170, 66, GREY);

    LCD_printString("TEMPLE", 64, 45, RED, 3);
    LCD_printString("FALL", 82, 80, RED, 3);

    LCD_Draw_Circle(120, 125, 7, GOLD, 1);
    LCD_Draw_Rect(112, 133, 18, 8, ORANGE, 1);
    LCD_Draw_Line(112, 136, 98, 148, GOLD);
    LCD_Draw_Line(130, 136, 144, 148, GOLD);
    LCD_Draw_Line(116, 141, 105, 155, BROWN);
    LCD_Draw_Line(126, 141, 137, 155, BROWN);

    LCD_Draw_Rect(45, 160, 150, 38, WHITE, 0);

    sprintf(txt, "SCORE %d", score);
    LCD_printString(txt, 62, 168, WHITE, 2);

    sprintf(txt, "TIME %lus", time_s);
    LCD_printString(txt, 70, 188, GOLD, 1);

    LCD_printString("RETRY", 18, 225, GREEN, 1);
    LCD_printString("MENU", 178, 225, RED, 1);

    LCD_Refresh(&cfg0);
}

MenuState Game2_Run(void)
{
    MenuState exit_state = MENU_STATE_HOME;
    int started = 0;

    reset_game();

    while (!started)
    {
        Input_Read();

        if (current_input.btn3_pressed)
        {
            return MENU_STATE_HOME;
        }

        if (current_input.btn2_pressed)
        {
            started = 1;
            beep_start();
        }

        draw_title_screen();
        HAL_Delay(80);
    }

    while (1)
    {
        uint32_t frame_start = HAL_GetTick();

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);
        UserInput joy = Joystick_GetInput(&joystick_data);

        if (current_input.btn3_pressed)
        {
            PWM_SetDuty(&pwm_cfg, 0);
            exit_state = MENU_STATE_HOME;
            break;
        }

        if (game_over)
        {
            draw_game_over();

            if (current_input.btn2_pressed)
            {
                reset_game();
                beep_start();
            }

            HAL_Delay(80);
            continue;
        }

        if (HAL_GetTick() - last_move > MOVE_DELAY)
        {
            if (joy.direction == W || joy.direction == NW || joy.direction == SW)
            {
                if (player_lane > 0)
                {
                    player_lane--;
                    last_move = HAL_GetTick();
                }
            }

            if (joy.direction == E || joy.direction == NE || joy.direction == SE)
            {
                if (player_lane < 2)
                {
                    player_lane++;
                    last_move = HAL_GetTick();
                }
            }
        }

        spike_y += speed;
        coin_y += speed;

        if (coin_y >= PLAYER_Y - 5 && coin_y <= PLAYER_Y + 30 && coin_lane == player_lane)
        {
            score += 2;

            if (speed < 8)
            {
                speed++;
            }

            reset_coin();
            beep_coin();
        }

        if (coin_y > 225)
        {
            reset_coin();
        }

        if (spike_y >= PLAYER_Y - 5)
        {
            if (spike_lane == player_lane)
            {
                lives--;
                beep_hit();
                blink_led_hit();

                if (lives <= 0)
                {
                    game_over = 1;
                }
            }
            else
            {
                score++;
            }

            reset_spike();
        }

        PWM_SetDuty(&pwm_cfg, 0);

        draw_play_screen();

        uint32_t frame_time = HAL_GetTick() - frame_start;

        if (frame_time < FRAME_MS)
        {
            HAL_Delay(FRAME_MS - frame_time);
        }
    }

    return exit_state;
}