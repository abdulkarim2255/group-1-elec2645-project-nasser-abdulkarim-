/**
 * @file  Menu.c
 * @brief Shared main-menu for the 2-game console.
 *
 * Two options: Gravity Well (game_1) and Temple Run (game_2).
 * Navigation: joystick up/down (edge-detected so holding doesn't flicker).
 * Selection: BTN3 (joystick click).
 * The function returns the chosen MenuState to main.c's outer loop.
 */
#include "Menu.h"
#include "LCD.h"
#include "InputHandler.h"
#include "Joystick.h"
#include "stm32l4xx_hal.h"
#include <stdio.h>

extern ST7789V2_cfg_t cfg0;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t     joystick_data;

static const char* menu_options[] = {
    "Gravity Well",   /* game_1 */
    "Temple Run"      /* game_2 */
};
#define NUM_OPTIONS   2
#define FRAME_MS     30   /* ~33 FPS */

static void render_menu(MenuSystem* m)
{
    LCD_Fill_Buffer(0);

    /* ---- title ---- */
    LCD_printString("GAMES CONSOLE", 20, 14, 1, 2);
    LCD_Draw_Line(0, 44, 239, 44, 15);

    /* ---- options ---- */
    for (uint8_t i = 0; i < NUM_OPTIONS; i++) {
        uint16_t y = 76 + (uint16_t)(i * 46);
        if (i == m->selected_option) {
            LCD_Draw_Rect(18, y - 6, 204, 30, 15, 0);  /* highlight box */
            LCD_printString(">", 26, y, 1, 2);
        }
        LCD_printString((char*)menu_options[i], 50, y, 1, 2);
    }

    /* ---- footer ---- */
    LCD_Draw_Line(0, 200, 239, 200, 15);
    LCD_printString("Joystick: navigate",   28, 210, 1, 1);
    LCD_printString("BTN3 (click): select", 18, 225, 1, 1);

    LCD_Refresh(&cfg0);
}

void Menu_Init(MenuSystem* menu)
{
    menu->selected_option = 0;
}

MenuState Menu_Run(MenuSystem* menu)
{
    static Direction last_dir = CENTRE;
    MenuState result           = MENU_STATE_HOME;

    while (1)
    {
        uint32_t t0 = HAL_GetTick();

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);
        Direction d = joystick_data.direction;

        /* edge-detected navigation */
        if (d == S && last_dir != S)
            menu->selected_option = (menu->selected_option + 1) % NUM_OPTIONS;
        else if (d == N && last_dir != N)
            menu->selected_option = (menu->selected_option == 0)
                                  ? (NUM_OPTIONS - 1)
                                  : (menu->selected_option - 1);
        last_dir = d;

        if (current_input.btn3_pressed) {
            result = (menu->selected_option == 0)
                   ? MENU_STATE_GAME_1   /* Gravity Well */
                   : MENU_STATE_GAME_2;  /* Temple Run   */
            break;
        }

        render_menu(menu);

        uint32_t elapsed = HAL_GetTick() - t0;
        if (elapsed < FRAME_MS) HAL_Delay(FRAME_MS - elapsed);
    }
    return result;
}
