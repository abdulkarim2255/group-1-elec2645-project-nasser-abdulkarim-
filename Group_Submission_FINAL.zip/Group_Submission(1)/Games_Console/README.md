# ELEC2645 Unit 4 — Games Console (2-person group)

A two-game arcade console on the **ST Nucleo-L476RG** with 240×240 LCD,
joystick, buzzer, PWM LED and two buttons.

## Games

| Slot | Title         | Author   | Core concept                                         |
|------|---------------|----------|------------------------------------------------------|
| 1    | Gravity Well  | Member A | Physics simulation: thrust + inverse-square gravity  |
| 2    | Sonar Sweep   | Member B | Hidden-information radar: sound encodes mine distance|

## Hardware wiring (identical to the Pong / Menu Template labs)

| Function     | Nucleo pin | Notes                               |
|--------------|-----------|--------------------------------------|
| LCD MOSI     | PB15      | SPI2                                 |
| LCD SCK      | PB13      | SPI2                                 |
| LCD CS       | PB12      |                                      |
| LCD DC       | PB11      |                                      |
| LCD RST      | PB2       |                                      |
| LCD BL       | PB1       |                                      |
| Joystick VRx | PA5 (A5)  | ADC1 ch1                             |
| Joystick VRy | PA4 (A4)  | ADC1 ch2                             |
| Joystick SW  | PC3       | BTN3 — menu select / game quit       |
| BTN2         | PC2       | game action (fire, flag, boost, start)|
| Buzzer +     | PB10      | TIM2 CH3 PWM                         |
| LED +        | PB6       | TIM4 CH1 PWM                         |

## Build and flash

1. Extract this zip. Open the **`Games_Console/`** folder (the one
   containing `CMakeLists.txt`) in STM32CubeIDE or VSCode with the
   ARM CMake toolchain.
2. **Build** (hammer icon). No errors expected.
3. Plug in Nucleo via USB. **Run + Debug** (bug icon) to flash.

## Controls

| Context       | Joystick          | BTN2              | BTN3         |
|---------------|-------------------|-------------------|--------------|
| Main menu     | Up/Down navigate  | —                 | Select       |
| Gravity Well  | Thrust direction  | Boost (2× thrust) | Quit to menu |
| Sonar Sweep   | Move crosshair    | Plant flag        | Quit to menu |

## Architecture in one diagram

```
power-on → [ MAIN MENU ] ──BTN3──► [ GRAVITY WELL ]──BTN3──►┐
                        └──BTN3──► [ SONAR SWEEP  ]──BTN3──►┘
                                                              │
                                              return MENU_STATE_HOME
```

`main.c` owns one outer `while(1)` loop and dispatches to
`Menu_Run()`, `Game1_Run()` or `Game2_Run()`. Each returns the next
`MenuState` when it exits. `game_3/` contains a one-line stub so the
template's `CMakeLists.txt` and `main.c` compile unchanged.

## Docs

```
docs/
├── personal_journal_member_A/     7 journal posts — Gravity Well
├── personal_journal_member_B_template/  7 journal templates — Sonar Sweep
├── group_journal/                 3 mandatory group journal posts
├── diagrams/                      SVG architecture + mock-up diagrams
└── video/                         8-minute group video script
```
